declare class MainUI extends eui.Skin{
}
