var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var LabelRenderer = (function (_super) {
    __extends(LabelRenderer, _super);
    function LabelRenderer() {
        var _this = _super.call(this) || this;
        _this.touchChildren = true;
        _this.labelDisplay = new eui.Label();
        _this.addChild(_this.labelDisplay);
        return _this;
    }
    LabelRenderer.prototype.dataChanged = function () {
        //显示数据中的 label 值
        this.labelDisplay.text = this.data.label;
    };
    return LabelRenderer;
}(eui.ItemRenderer));
__reflect(LabelRenderer.prototype, "LabelRenderer");
//# sourceMappingURL=LabelRenderer .js.map