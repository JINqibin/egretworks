class TableUI extends eui.Component {
        constructor() {
            super();
            this.skinName = "resource/eui_skins/TableUI.exml";
        }
        public bg:eui.Image;
        public againg:eui.Image;
        private step:number=225;
        private isWhite:boolean = true; //设置是否该轮到白棋，黑棋先手 默认玩家先出
        private winner:string='';//获胜玩家
        private chessData:number[][]=new Array(15);
        protected createChildren(): void {
            super.createChildren();
            this.bg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.obtainFunc, this);
            this.againg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.againgame, this);
            this.addEventListener(egret.Event.ADDED_TO_STAGE,this.onAddToStage,this);
            //二维数组存储棋盘落子信息,初始化数组chessData值为0即此处没有棋子，1为白棋，2为黑棋
            for (var x = 0; x < 15; x++) {
                this.chessData[x] = new Array(15);
               for (var y = 0; y < 15; y++) {
                this.chessData[x][y] = 0;
               }
           }
        }
        //创建棋盘
        private onAddToStage(event:egret.Event)
        {
            var shp:egret.Shape = new egret.Shape();
            shp.graphics.lineStyle( 1, 0x000000 );
            var x=50; 
            var y=50; 
            for(var i=0;i<15;i++){
              shp.graphics.moveTo( 50 , 50 + i*40 );
              shp.graphics.lineTo( 611 , 50 + i*40 );
              shp.graphics.moveTo( 50  + i*40 , 50 );
              shp.graphics.lineTo( 50  + i*40, 611);
            }
            shp.graphics.endFill();
            this.addChild( shp );
        }
        //重新开始
        private againgame(){
          this.winner='';
          this.removeChildren();
          this.addChild(new TableUI);

        }

        //玩家落子
        private obtainFunc(e:egret.TouchEvent){
             var x=Math.round((e.stageX-50)/40);
             var y=Math.round((e.stageY-50)/40);
             if (x < 0 || y < 0 || x > 14 || y > 14 || this.chessData[x][y] != 0) { //鼠标点击棋盘外的区域不响应
               return;
             }else{
                this.doCheck(x,y);
             }
        }
        //判断谁出
        private doCheck(x, y) {
             if (this.winner != '' && this.winner != null) { //已经结束的游戏只能点击new game
                 alert(this.winner);
                 return;
             }
             if (this.isWhite) {
               this.drawChess(0x000000, x, y);
             } else {
               this.drawChess(0xffffff, x, y);
             }
        }
        // 落子
        private drawChess(color, x, y) { 
          if (x >= 0 && x < 15 && y >= 0 && y < 15) {
            if (color == 0x000000) {//黑
              this.chess(color, x, y);
              this.isWin(color, x, y); //判断输赢
              this.isWhite = false;
              this.AIplay();
            } 
            else {//白
              this.chess(color, x, y);
              this.isWin(color, x, y); //判断输赢
              this.isWhite = true;
            }
          }
          if(--this.step==0){
              this.winner="和局";
              alert("平局")
          }
        }
        //创建棋子 color 棋子颜色 x y位置

        private chess(color,x,y){
             if (x < 0 || y < 0 || x > 14 || y > 14 || this.chessData[x][y] != 0) { //鼠标点击棋盘外的区域不响应
               return;
             }
             var shp:egret.Shape = new egret.Shape();
             shp.graphics.beginFill( color, 1);
             shp.graphics.drawCircle( x * 40 + 50, y * 40 + 50, 15 );
             shp.graphics.endFill();

             this.addChild( shp );

             if (color == 0x000000) {
                 console.log("黑棋在"+ x + "," + y)
                 this.chessData[x][y] = 1;
             } else {
                 console.log("白棋在"+ x + "," + y)
                 this.chessData[x][y] = 2;
             }

        }
        //判断输赢
        private isWin(color, x, y){
             var temp = 2; //默认为白
             if (color == 0x000000) {
               temp = 1;
             } //黑色
             this.lrCount(temp, x, y);
             this.tbCount(temp, x, y);
             this.rtCount(temp, x, y);
             this.rbCount(temp, x, y);
        }
        private lrCount(temp, x, y) {
            //判断左边右边
            var lis=new Array(4);
            var t=0;
            //左边
            for(var i=x;i>=0;i--){
                lis[0]=i;
                lis[1]=y;
                if(this.chessData[i][y] == temp){
                    ++t;
                }else{
                    i=-1;
                }
            }
            //右边
            for(var i=x;i<=14;i++){
               lis[3]=i;
               lis[4]=y;
               if(this.chessData[i][y] == temp){
                   ++t;

               }else{
                   i=15;
               }
            }
            this.success(lis[0], lis[1], lis[2], lis[3], temp, --t);
        }
        //判断上下
        private tbCount(temp, x, y) {
          var lis = new Array(4);
          var t = 0;
          //上
          for (var i = y; i >= 0; i--) {
            lis[0] = x;
            lis[1] = i;
            if (this.chessData[x][i] == temp) {
              ++t;
            } else {
              i = -1;
            }
          }
          //下
          for (var i = y; i <= 14; i++) {
            lis[2] = x;
            lis[3] = i;
            if (this.chessData[x][i] == temp) {
              ++t;
            } else {
              i = 200;
            }
          }
          this.success(lis[0], lis[1], lis[2], lis[3], temp, --t);
        }
        //判断左上斜
        private rtCount(temp, x, y) {
          var lis = new Array(4);
          var t = 0;
         
          for(var i=x,j=y;i<=14&&j>=0;i++,j--){
              lis[0]=i
              lis[1]=j
              if(this.chessData[i][j] == temp){
                  ++t;
              }else{
                 i = 15;
              }

          }
          for (var i = x, j = y; i >= 0 && j <= 14;i--,j++) {
            lis[2] = i;
            lis[3] = j;
            if (this.chessData[i][j] == temp) {
              ++t;
            } else {
              i = -1;
            }
          }
          this.success(lis[0], lis[1], lis[2], lis[3], temp, --t);
        }

        private rbCount(temp, x, y) {
          //右下斜判断
          var lis = new Array(4);
          var t = 0;
        
          for (var i = x, j = y; i >= 0 && j >= 0;i--,j--) {
            lis[0] = i;
            lis[1] = j;
            if (this.chessData[i][j] == temp) {
              ++t;
            } else {
              i = -1;
            }
          }
          for (var i = x, j = y; i <= 14 && j <= 14;i++,j++) {
            lis[2] = i;
            lis[3] = j;
            if (this.chessData[i][j] == temp) {
              ++t;
            } else {
              i = 100;
            }
          }
          this.success(lis[0], lis[1], lis[2], lis[3], temp, --t);
        }
        //胜利
        private success(a, b, c, d, temp, t) {
          if (t >= 5) { //因为落子点重复计算了一次
            console.log("此局游戏结束啦");
                this.winner = "黑棋胜利!";
                if (temp == 2) {
                  this.winner = "白棋胜利!";
                }
                alert(this.winner);
          }
        }
        //电脑出牌
        private  AIplay() {
            var str=this.getPosition();
            console.log(str)
            this.doCheck(str[0],str[1])
        }
/**五子棋AI
 *思路：对棋盘上的每一个空格进行估分，电脑优先在分值高的点落子
 * 棋型：
 * 〖五连〗只有五枚同色棋子在一条阳线或阴线上相邻成一排
 * 〖成五〗含有五枚同色棋子所形成的连，包括五连和长连。
 * 〖活四〗有两个点可以成五的四。
 * 〖冲四〗只有一个点可以成五的四。
 * 〖死四〗不能成五的四。
 * 〖三〗在一条阳线或阴线上连续相邻的5个点上只有三枚同色棋子的棋型。
 * 〖活三〗再走一着可以形成活四的三。
 * 〖连活三〗即：连的活三（同色棋子在一条阳线或阴线上相邻成一排的活三）。简称“连三”。
 * 〖跳活三〗中间隔有一个空点的活三。简称“跳三”。
 * 〖眠三〗再走一着可以形成冲四的三。
 * 〖死三〗不能成五的三。
 * 〖二〗在一条阳线或阴线上连续相邻的5个点上只有两枚同色棋子的棋型。
 * 〖活二〗再走一着可以形成活三的二。
 * 〖连活二〗即：连的活二（同色棋子在一条阳线或阴线上相邻成一排的活二）。简称“连二”。
 * 〖跳活二〗中间隔有一个空点的活二。简称“跳二”。
 * 〖大跳活二〗中间隔有两个空点的活二。简称“大跳二”。
 * 〖眠二〗再走一着可以形成眠三的二。
 * 〖死二〗不能成五的二。
 * 〖先手〗对方必须应答的着法，相对于先手而言，冲四称为“绝对先手”。
 * 〖三三〗一子落下同时形成两个活三。也称“双三”。
 * 〖四四〗一子落下同时形成两个冲四。也称“双四”。
 * 〖四三〗一子落下同时形成一个冲四和一个活三。
 * 分值表
 * 成5:100000分
 * 活4：10000分
 * 活3+冲4:5000分
 * 眠3+活2：2000分
 * 眠2+眠1:1分
 * 死棋即不能成5的是0分
 * @return {[type]} [description]
 */        
        private getPosition(){
          var a= new Array(2);
          var score = 0;
          for(var i=0;i<15;i++){
            for(var j=0;j<15;j++){
              if(this.chessData[i][j]==0){
                 if(this.judge(i,j)>score){
                   score=this.judge(i,j);//取最大分
                   a[0]=i;
                   a[1]=j;
                 }
              }
            }
          } 
          return a;
        }
        private judge(x, y) {
	          var a =this.leftRight(x,y,2) +this.topBottom(x, y, 2)+this.rightBottom(x,y,2)+this.rightTop(x,y,2)+100//判断白棋走该位置的得分
	          var b =this.leftRight(x,y,1) +this.topBottom(x, y, 1)+this.rightBottom(x,y,1)+this.rightTop(x,y,1) //判断黑棋走该位置的得分
	          var result = a + b;
	          //console.log("我计算出了" + x + "," + y + "这个位置的得分为" + result);
	          return result; //返回黑白棋下该位置的总和
        }

        private leftRight(x:number, y:number, num) {
	          var death = 0; //0表示两边都没堵住,且可以成5，1表示一边堵住了，可以成5,2表示是死棋，不予考虑
	          var live = 0;
	          var count = 0;
	          var arr = new Array(15);
	          for (var i = 0; i< 15; i++) {
	          	arr[i] = new Array(15);
	          	for (var j = 0; j < 15; j++) {
	          		arr[i][j] = this.chessData[i][j];
	          	}
	          }
	          arr[x][y] = num;
	          for (var i = x; i >= 0; i--) {
	          	if (arr[i][y] == num) {
	          		count++;
	          	} else if (arr[i][y] == 0) {
	          		live += 1; //空位标记
	          		i = -1;
	          	} else {
	          		death += 1; //颜色不同是标记一边被堵住
	          		i = -1;
	          	}
	          }
	          for (var i = x; i <= 14; i++) {
	          	if (arr[i][y] == num) {
	          		count++;
	          	} else if (arr[i][y] == 0) {
	          		live += 1; //空位标记
	          		i = 100;
	          	} else {
	          		death += 1;
	          		i = 100;
	          	}
	          }
	          count -= 1;
	          return this.model(count, death,live);
        }
        
        private topBottom(x:number, y:number, num) {
	          var death = 0; //0表示两边都没堵住,且可以成5，1表示一边堵住了，可以成5,2表示是死棋，不予考虑
	          var live = 0;
	          var count = 0;
	          var arr = new Array(15);
	          for (var i = 0; i< 15; i++) {
	          	arr[i] = new Array(15);
	          	for (var j = 0; j < 15; j++) {
	          		arr[i][j] = this.chessData[i][j];
	          	}
	          }
	          arr[x][y] = num;
	          for (var i = y; i >= 0; i--) {
	          	if (arr[x][i] == num) {
	          		count++;
	          	} else if (arr[x][i] == 0) {
	          		live += 1; //空位标记
	          		i = -1;
	          	} else {
	          		death += 1;
	          		i = -1;
	          	}
	          }
	          for (var i = y; i <= 14; i++) {
	          	if (arr[x][i] == num) {
	          		count++;
	          	} else if (arr[x][i] == 0) {
	          		live += 1; //空位标记
	          		i = 100;
	          	} else {
	          		death += 1;
	          		i = 100;
	          	}
	          }
	          count -= 1;
	          return this.model(count, death,live);
        }
        private rightBottom(x:number, y:number, num){
            var death = 0; //0表示两边都没堵住,且可以成5，1表示一边堵住了，可以成5,2表示是死棋，不予考虑
	          var live = 0;
	          var count = 0;
	          var arr = new Array(15);
	          for (var i = 0; i< 15; i++) {
	          	arr[i] = new Array(15);
	          	for (var j = 0; j < 15; j++) {
	          		arr[i][j] = this.chessData[i][j];
	          	}
	          }
	          arr[x][y] = num;
	          for (var i = x, j = y; i >= 0 && j >= 0;) {
	          	if (arr[i][j] == num) {
	          		count++;
	          	} else if (arr[i][j] == 0) {
	          		live += 1; //空位标记
	          		i = -1;
	          	} else {
	          		death += 1;
	          		i = -1;
	          	}
	          	i--;
	          	j--;
	          }
	          for (var i = x, j = y; i <= 14 && j <= 14;) {
	          	if (arr[i][j] == num) {
	          		count++;
	          	} else if (arr[i][j] == 0) {
	          		live += 1; //空位标记
	          		i = 100;
	          	} else {
	          		death += 1;
	          		i = 100;
	          	}
	          	i++;
	          	j++;
	          }
	          count -= 1;
	          return this.model(count, death,live);
        }
        private rightTop(x:number, y:number, num){
            var death = 0; //0表示两边都没堵住,且可以成5，1表示一边堵住了，可以成5,2表示是死棋，不予考虑
	          var live = 0;
	          var count = 0;
	          var arr = new Array(15);
	          for (var i = 0; i< 15; i++) {
	          	arr[i] = new Array(15);
	          	for (var j = 0; j < 15; j++) {
	          		arr[i][j] = this.chessData[i][j];
	          	}
	          }
	          arr[x][y] = num;
	          for (var i = x, j = y; i >= 0 && j <= 14;) {
	          	if (arr[i][j] == num) {
	          		count++;
	          	} else if (arr[i][j] == 0) {
	          		live += 1; //空位标记
	          		i = -1;
	          	} else {
	          		death += 1;
	          		i = -1;
	          	}
	          	i--;
	          	j++;
	          }
	          for (var i = x, j = y; i <= 14 && j >= 0;) {
	          	if (arr[i][j] == num) {
	          		count++;
	          	} else if (arr[i][j] == 0) {
	          		live += 1; //空位标记
	          		i = 100;
	          	} else {
	          		death += 1;
	          		i = 100;
	          	}
	          	i++;
	          	j--;
	          }
	          count -= 1;
	          return this.model(count, death , live);
        }

        private model(count, death,live) {
	          var LEVEL_ONE = 0;//单子
	          var LEVEL_TWO = 1;//眠2，眠1
	          var LEVEL_THREE = 100;//活2
	          var LEVEL_THREE2 = 2000;//眠3
	          var LEVEL_FOER = 4000;//活3
	          var LEVEL_FOER2 = 5000;//冲4
	          var LEVEL_FIVE = 10000;//活4
	          var LEVEL_SIX = 100000;//成5
	          if (count == 1 && death == 1) {
	          	return LEVEL_TWO; //眠1
	          } else if (count == 2) {
	          	if (death == 0) {
	          		return LEVEL_THREE; //活2
	          	} else if (death == 1) {
	          		return LEVEL_TWO; //眠2
	          	} else {
	          		return LEVEL_ONE; //死棋
	          	}
	          } else if (count == 3) {
	          	if (death == 0) {
	          		return LEVEL_FOER; //活3
	          	} else if (death == 1) {
	          		return LEVEL_THREE2; //眠3
	          	} else {
	          		return LEVEL_ONE; //死棋
	          	}
	          } else if (count == 4) {
	          	if (death == 0) {
	          		return LEVEL_FIVE; //活4
	          	} else if (death == 1) {
	          		return LEVEL_FOER2; //冲4
	          	} else {
	          		return LEVEL_ONE; //死棋
	          	}
	          } else if (count == 5) {
	          	return LEVEL_SIX; //成5
	          }
	          return LEVEL_ONE;
        }
}